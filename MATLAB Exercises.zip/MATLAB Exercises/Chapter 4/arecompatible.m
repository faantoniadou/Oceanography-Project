function [] = arecompatible(A,B)
    if size(A,1) ~= size(A,2)
            disp('Error: Matrix A is not square');
    elseif size(B,1) ~= size(B,2)
            disp('Error: Matrix B is not square');
    else
        if size(A) ~= size(B)
            disp('Error: Matrices are not of the same size');
        else
            AB = A * B;
            BA = B * A;
            
            switch isequal(AB,BA)
                case 1
                    disp(1)
                otherwise
                    disp(0)
            end
        end
    end

    
