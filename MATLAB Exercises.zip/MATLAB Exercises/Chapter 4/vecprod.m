function [product] = vecprod(x,y,n)
    product=1;
    for i = 1:n
        product = product * abs(x(i) - y(i));
    end
    
        