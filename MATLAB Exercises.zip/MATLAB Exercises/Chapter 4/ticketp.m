function [] = ticketp()
    city = input('Enter destination city: ', 's');
        if city == 'Paphos' 
            disp('50 CYP');
        elseif city == 'Athens'
            disp('150 CYP');
        elseif city == 'Heraklion'
            disp('110 CYP');
        elseif city == 'Thessaloniki'
            disp('200 CYP');
        else
            sprintf('No flights for %s',city)
        end