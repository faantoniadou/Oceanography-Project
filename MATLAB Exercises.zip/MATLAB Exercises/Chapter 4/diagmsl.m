function [x] = diagmsl(A, b)
    R = rref(A);
    if size(A,1) ~= size(A,2)
            disp('Error: The matrix is not square');
    elseif size(A,2) ~= size(b,1)
            disp('Error: Array dimensions do not match');
    elseif det(A) == 0
            disp('Error: Matrix A is not invertible');    
            
    else 
        for i = 1:size(R,1)
            for j = 1:size(R,2)
                if i ~= j
                    if R(i,j) ~= 0
                        disp('Error: The matrix is not diagonal');
                    else
                        x = linsolve(A,b);
                    end
                elseif i == j
                    if R(i,j) == 0 
                        disp('Error: The matrix is not diagonal');
                    else
                        x = linsolve(A,b);
                    end
                end
            end
        end
    end
        
                   
            
    
            