function [p] = appr(n,x)
    p = 0;
    for i = 0:n
        p = p + x^n/factorial(n);
    end
    