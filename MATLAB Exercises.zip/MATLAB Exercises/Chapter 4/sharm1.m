function [sum1] = sharm1(n)
    sum1 = 0;
    for k = 1:n
        hold on
        sum1 = sum1 + 1/k;
        plot(k,sum1)
    end
