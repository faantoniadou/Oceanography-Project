function [] = issingular(A)
    if size(A,1) ~= size(A,2)
            disp('Error: The matrix is not square');
    else
        detA=det(A);
        switch detA
            case 0
                disp(1)
            otherwise
                disp(0)
        end
    end