function [epsilon] = uncerterror(n)
    for x = -2:0.1:2
        epsilon = abs(appr(n,x) - exp(x));
        hold on
        plot(x, epsilon, '.')
    end
    