function [a] = lowerm(n)
    
    for i = 1:n
        for j = 1:n
            if j <= i
                a(i,j) = (i+j)/2;
            else
                a(i,j) = 0;
            end
        end
    end
            
        