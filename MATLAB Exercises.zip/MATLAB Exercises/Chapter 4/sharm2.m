function [sum2] = sharm2(n)
    sum2 = 0;
    for k = 1:n
        hold on
        sum2 = sum2 + 1/k^2;
        plot(k,sum2,'.');
        hold off
    end