function [a] = nameij(m,n)

    for i = 1:m
        for j = 1:n
            a(i,j) = (1+i)/(1+j);
        end
    end
    