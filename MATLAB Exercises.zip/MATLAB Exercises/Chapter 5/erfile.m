function [u] = erfile(y,t)
u = 1 - erf(y./(2*sqrt(t)));

