function [u] = poisrect(y,z,b,N)
sigma = 0;
for k = 1:N
    a_k = (2 .* k -1)*pi/2;
    sigma = sigma+ ((((-1.)^k)*cosh(a_k.*y))./(a_k^3.*cosh(a_k.*b))).*cos(a_k .*z);
end
u = 0.5 * (1 - z.^2 + 4 .* sigma);