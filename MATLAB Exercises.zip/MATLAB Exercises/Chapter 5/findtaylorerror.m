function [e] = findtaylorerror(x,n)

e = abs(exp(x) - findtaylor(x,n));

