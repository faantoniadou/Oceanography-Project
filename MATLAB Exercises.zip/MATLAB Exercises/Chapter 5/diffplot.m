function diffplot
    x = [-2:0.1:4];
    f = 3*x.^3 - 26.*x +10;
    df = gradient(f);
    d2f = gradient(df);
    
    hold on;
    plot(x,f)
    plot(x,df)
    plot(x,d2f)
    xlabel('x');
    title('Plot of first and second derivative of f(x)');
    legend('f','df','d2f');
        
    
    
    
        
    