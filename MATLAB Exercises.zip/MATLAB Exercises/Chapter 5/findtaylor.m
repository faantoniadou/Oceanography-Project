function [p] = findtaylor(x,n)
p = 0;
for i = 0:n
    p = (p + x.^i/factorial(i));
end