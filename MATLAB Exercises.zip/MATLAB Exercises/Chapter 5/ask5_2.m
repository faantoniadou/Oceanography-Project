function [] = ask5_2(a,b,n)
    x = linspace(a,b,n);
    y = sin(x);
    z = cos(x);
    plot(x,y,x,z)
    xlabel('x');
    title('Graph of cosine and sine');
    legend('cos(x)','sin(x)');
    