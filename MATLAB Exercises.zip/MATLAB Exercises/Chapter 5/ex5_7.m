x = linspace(-1,3,400);
y = linspace(1,4,400);
z = @(x,y) ((x .* y.^2)/(x.^2 + y.^2));
ezsurf(z);
xlabel('x')
ylabel('y')
zlabel('z')
legend
title('3D plot')
