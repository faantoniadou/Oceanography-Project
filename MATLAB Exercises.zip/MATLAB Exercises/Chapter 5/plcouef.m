function [u] = plcouef(y,t,N)
sigma =0;
for k = 1:N
    sigma = sigma + (1/k)*sin(k*pi*y)*exp(-k^2*pi^2*t);
end

u = 1 - y - (2/pi)*sigma; 