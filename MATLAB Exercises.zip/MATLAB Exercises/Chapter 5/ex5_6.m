x = [0.1:0.1:60];
h = @(x) (2.^(-0.2.*x + 10));

subplot(2,2,1);plot(x,h(x));
title('Linear')
xlabel('x')
ylabel('h(x)')
subplot(2,2,2);loglog(x,h(x));
title('Logarithmic')
xlabel('x')
ylabel('h(x)')
subplot(2,2,3);semilogy(x,h(x));
title('Lin/Log')
xlabel('x')
ylabel('h(x)')
subplot(2,2,4);semilogx(x,h(x));
title('Log/Lin')
xlabel('x')
ylabel('h(x)')


