function []
    x = [-2:0.1:4];
    f = 3*x^3 - 26*x +10;
    for i = 1:numel(x)
        f(i) = 3 * x(i).^3 - 26 * x(i +10;
        f'(i) = diff(f(i));
        f''(i) = diff(f'(i));
    end
    hold on;
    plot(x,f)
    plot(x,f')
    plot(x,f'')
    
        
    