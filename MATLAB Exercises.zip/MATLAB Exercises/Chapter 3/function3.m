function [f3] = function3(x, y)
    f3 = y^2 * x^4 + x * y - 5;
