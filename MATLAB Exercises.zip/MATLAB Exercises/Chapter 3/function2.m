function [f2] = function2(x)
    f2 = 3 * x^3 - 2 * x^2 - 1;
