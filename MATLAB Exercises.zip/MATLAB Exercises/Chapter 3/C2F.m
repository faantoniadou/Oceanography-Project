%convert from fahrenheit to celsius
format
format compact
F = input('Temperature in Fahrenheit: ');
disp(' The temperature in Celsius is ') 
C = ((F -32) * 5) / 9