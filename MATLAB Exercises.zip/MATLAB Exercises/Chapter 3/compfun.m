function [z] = compfun(strfun,x)
    y = feval(strfun, x);
    z = feval(strfun, y);
     