function [f1] = function1(x)
    f1 = cos(x)^2 - sin(x)^2;


