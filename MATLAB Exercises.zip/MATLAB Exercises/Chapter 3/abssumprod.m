% Faidra Antoniadou
% Calculating the sum and product of the absolute values of 4 numbers
% Function name: abssumprod
% File name: abssumprod.m
% Input variables: x1, x2, x3
% Output variables: absolute value of sum
%                   absolute value of product

function [abssum, absprod ] = abssumprod(x1, x2, x3)

    abssum = abs(x1) + abs(x2) + abs(x3);
    absprod = abs(x1) * abs(x2) * abs(x3);