% Faidra Antoniadou
% This function converts radians to degrees

function [deg] = radtodeg(~)
    rad = input(' Radians: ');
    deg = rad * (180/pi);
   