% Faidra Antoniadou
% Function that computes the element-wise square of a matrix, the sum of
% the resultant elements and the sum's root.

function [A2, elsum, root] = euclnrm(A)
    A2 = A .* A;
    elsum = sum(A2, 'all');
    root = sqrt(elsum);
    
