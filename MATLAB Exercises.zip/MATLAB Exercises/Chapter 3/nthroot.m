% Faidra Antoniadou
% This function computed the nth root of x

function [nthroot] = nthroot(x , n)
    x = input('x = ');
    n = input('n = ');
    nthroot = x ^ (1/n);