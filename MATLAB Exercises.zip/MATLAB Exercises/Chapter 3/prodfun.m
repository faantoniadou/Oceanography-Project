function [z] = prodfun(f, g, x)
    w = feval(f, x);
    y = feval(g, x);
    z = w * y;