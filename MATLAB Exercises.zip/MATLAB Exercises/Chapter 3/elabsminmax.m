function [] = elabsminmax(~)
    A = input('Matrix: ' );
    absA = abs(A);
    elabsmin = min(absA, [], 'all');
    elabsmax = max(absA, [], 'all'); 
    fprintf('Maximum = %g', elabsmax);
    fprintf('\n')
    fprintf('Minimum = %g', elabsmin);
    fprintf('\n')

    