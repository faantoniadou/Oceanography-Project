% Faidra Antoniadou
% This function converts degrees to radians

function [rad] = degtorad(~)
    degrees = input(' Degrees: ');
    rad = degrees * (pi/180);
   
    
    
    
  