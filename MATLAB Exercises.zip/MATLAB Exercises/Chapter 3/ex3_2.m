function [y,z,w] = ex3_2(x)
    y = x / 10^5;
    z = (x + y)/100;
    w = x * y * z;