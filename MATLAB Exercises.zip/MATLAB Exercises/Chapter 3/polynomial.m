
function [P] = polynomial(x)
    P = 3* x^3 + 5 * x^2 - 2 * x + 1;