% Faidra Antoniadou
% Function that calculates the square, determinant and rank of a square matrix

function [A2, detA2, rankA2] = newmiscop(A)
    A2 = A * A;
    detA2 = det(A2);
    rankA2 = rank(A2);
    
    