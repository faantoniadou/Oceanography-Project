% This function computes the trace and determinant of the product of two
% square matrices A and B

function [AB, traceAB, detAB] = dettrace(A, B)
    AB = A * B;
    traceAB = trace(AB);
    detAB = det(AB);