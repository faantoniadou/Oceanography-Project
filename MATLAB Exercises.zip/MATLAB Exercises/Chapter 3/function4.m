function [f4] = function4(x,y,z)
    f4 = (x * y * z)/(x^2 + y^2 + z^2);
