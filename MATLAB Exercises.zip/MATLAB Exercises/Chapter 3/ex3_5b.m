function [] = ex3_5b(P1,P2,r,t1)
    n2 = 12;
    syms t;
    time = solve(P2 * (1+r/n2)^(n2 * t) == P1 * (1 + r)^t1,t);
    T = double(time);
    years = floor(T);
    remainder = rem(T,1)*12;
    if remainder < 0
        months = 12 - round(rem(T,1) * 12);
    else 
        months = round(rem(T,1) * 12);
    end
       
    fprintf('%g', years)    
    fprintf(' years and %g', months);
    fprintf(' months');
    fprintf('\n')