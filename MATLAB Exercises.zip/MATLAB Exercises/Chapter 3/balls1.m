function [N] = balls1(~, ~, ~)
    d = 1.54;
    b = 8;
    h = 14;
    VC = (h * pi) * (b / 2)^2;
    VB = d^3;
    N = fix(VC / VB);