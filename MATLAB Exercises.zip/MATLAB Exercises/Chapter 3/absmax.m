
function [elabsmax] = absmax(A);
    A = input('Matrix: ' );
    absA = abs(A);
    elabsmax = max(absA, [], 'all');
    
    