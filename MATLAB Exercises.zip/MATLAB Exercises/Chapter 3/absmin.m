function [elabsmin] = absmin(A);
    A = input('Matrix: ' );
    absA = abs(A);
    elabsmin = min(absA, [], 'all');
    