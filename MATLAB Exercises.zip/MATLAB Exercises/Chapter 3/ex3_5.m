function [] = ex3_5(~)
    n2 = 12;
    r = 0.085;
    syms t;
    time = solve((1+r/n2)^(n2 * t) == (1 + r)^17,t);
    T = double(time);
    months = round(rem(T,1) * 12);
    fprintf(' 16 years and %g', months);
    fprintf(' months');
    fprintf('\n')