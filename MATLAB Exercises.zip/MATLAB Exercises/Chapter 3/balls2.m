function [N] = balls1(d, b, h)
    VC = (h * pi) * (b / 2)^2;
    VB = d^3;
    N = fix(VC / VB);