function [pton] = pconv(p,n)
    pton = conv(p,p);
for i = 3:n
    pton = conv(pton, p);
end
