function [pplusq] = polyadd(p,q)
degp1 = length(p);
      degq1 = length(q);
      if degp1==degq1
          pplusq =p + q;
      elseif degp1>degq1
          pplusq = p + [zeros(1, degp1-degq1) q];
      else
          pplusq = q + [zeros(1, degq1-degp1) p];
      end
if nnz(pplusq) < length(q) || length(pplusq) < length(p)
    pplusq = nonzeros(pplusq)';
end

    