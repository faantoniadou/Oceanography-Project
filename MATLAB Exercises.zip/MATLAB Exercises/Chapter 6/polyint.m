function [I] = polyintegral(p)
I = polyint(p);
end