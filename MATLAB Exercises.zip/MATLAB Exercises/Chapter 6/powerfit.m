function [b,m] = powerfit(X,Y)

p = polyfit(X,log(Y),1);
m = p(1);
b = exp(p(2));

